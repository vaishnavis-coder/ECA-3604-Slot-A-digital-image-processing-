% Read the grayscale image
img = imread('cameraman.tif');

% Display the image
imshow(img);
title('Grayscale Image');

% Find dimensions of the image
[rows, columns] = size(img);

% Calculate total number of pixels
total_pixels = rows * columns;

% Find minimum and maximum intensity
min_intensity = min(img(:));
max_intensity = max(img(:));

% Display the results
fprintf('Image Dimensions: %d x %d\n', rows, columns);
fprintf('Total Number of Pixels: %d\n', total_pixels);
fprintf('Minimum Intensity: %d\n', min_intensity);
fprintf('Maximum Intensity: %d\n', max_intensity);

% Display intensity values of selected pixels
fprintf('Intensity at (50,50): %d\n', img(50,50));
fprintf('Intensity at (100,100): %d\n', img(100,100));
fprintf('Intensity at (150,150): %d\n', img(150,150));

% Display a small portion of the image matrix
disp('First 5 x 5 intensity values:');
disp(img(1:5,1:5));
