% Clear workspace and command window
clear; clc; close all;

% 1. Read the grayscale image
img = imread('cameraman.tif'); % Replace with your image file name if different

% Convert to grayscale if the image has 3 color channels (RGB)
if size(img, 3) == 3
    img = rgb2gray(img);
end

% 2. Display the image
figure;
imshow(img);
title('Grayscale Image');

% 3. Determine image dimensions
[rows, columns] = size(img);

% 4. Calculate total number of pixels
total_pixels = rows * columns;

% 5. Find minimum and maximum intensity values
min_intensity = min(img(:));
max_intensity = max(img(:));

% 6. Display primary statistics in Command Window
fprintf('=== Image Details ===\n');
fprintf('Image Dimensions : %d x %d\n', rows, columns);
fprintf('Total Pixels     : %d\n', total_pixels);
fprintf('Min Intensity    : %d\n', min_intensity);
fprintf('Max Intensity    : %d\n\n', max_intensity);

% 7. Select and display intensity values of specific pixels
% Selecting top-left region, center, and bottom-right region
p1_r = round(rows * 0.25); p1_c = round(columns * 0.25);
p2_r = round(rows * 0.50); p2_c = round(columns * 0.50);
p3_r = round(rows * 0.75); p3_c = round(columns * 0.75);

fprintf('=== Selected Pixel Intensity Values ===\n');
fprintf('Pixel at (Row %d, Col %d)  : %d\n', p1_r, p1_c, img(p1_r, p1_c));
fprintf('Pixel at (Row %d, Col %d) : %d\n', p2_r, p2_c, img(p2_r, p2_c));
fprintf('Pixel at (Row %d, Col %d) : %d\n\n', p3_r, p3_c, img(p3_r, p3_c));

% 8. Output matrix representation explanation to Command Window
fprintf('=== Matrix Representation Explanation ===\n');
fprintf('1. A grayscale image is stored as a 2D matrix of dimensions %d x %d.\n', rows, columns);
fprintf('2. Matrix indices (i, j) correspond to pixel coordinates at Row i and Column j.\n');
fprintf('3. Each element stores a numeric intensity value of type uint8 (8-bit unsigned integer).\n');
fprintf('4. Values range from 0 to 255, where 0 represents pure black, 255 represents pure white, and intermediate values represent shades of gray.\n');