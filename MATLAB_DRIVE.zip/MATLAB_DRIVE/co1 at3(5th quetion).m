clc;
clear;
close all;

img = imread('cameraman.tif');

region = img(50:59, 50:59);

figure;
imshow(region);
title('10 x 10 Grayscale Region');

disp('Numerical Matrix:');
disp(region);

darkest = min(region(:));
brightest = max(region(:));

fprintf('Darkest pixel value: %d\n', darkest);
fprintf('Brightest pixel value: %d\n', brightest);