clc;
clear;
close all;

% Read grayscale image
I = imread('cameraman.tif');

% Select a 10 x 10 region (rows 100–109, columns 100–109)
R = I(100:109, 100:109);

% Display the original grayscale image
figure;
imshow(I);
title('Original Grayscale Image');

% Enlarge and display the selected region
figure;
imshow(R, 'InitialMagnification', 800, 'Interpolation', 'nearest');
title('Selected 10 x 10 Region (Enlarged)');

% Display numerical matrix in the Command Window

disp('10 x 10 Numerical Matrix:');
disp(R);

% Find darkest and brightest pixels and their positions within R
[darkest, idxDark] = min(R(:));
[row_dark, col_dark] = ind2sub(size(R), idxDark);

[brightest, idxBright] = max(R(:));
[row_bright, col_bright] = ind2sub(size(R), idxBright);

fprintf('Darkest Pixel Value = %d\n', darkest);
fprintf('Darkest Pixel Position within region = (%d, %d)\n', row_dark, col_dark);
fprintf('Brightest Pixel Value = %d\n', brightest);
fprintf('Brightest Pixel Position within region = (%d, %d)\n', row_bright, col_bright);