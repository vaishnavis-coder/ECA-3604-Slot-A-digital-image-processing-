clc;
clear;
close all;

% Read the grayscale image
I = imread('cameraman.tif');

% Display the image
imshow(I);
title('Grayscale Image');

% Determine image dimensions
[rows, cols] = size(I);

% Calculate total number of pixels
total_pixels = rows * cols;

% Find minimum and maximum intensity
min_intensity = min(I(:));
max_intensity = max(I(:));

% Display the results
fprintf('Image Dimensions: %d x %d\n', rows, cols);
fprintf('Total Number of Pixels: %d\n', total_pixels);
fprintf('Minimum Intensity: %d\n', min_intensity);
fprintf('Maximum Intensity: %d\n', max_intensity);

% Display intensity values of selected pixels
fprintf('Intensity at (50,50): %d\n', I(50,50));
fprintf('Intensity at (100,100): %d\n', I(100,100));
fprintf('Intensity at (150,150): %d\n', I(150,150));

% Display the image as a matrix
disp('Matrix representation of selected 5x5 region:');
disp(I(1:5,1:5));